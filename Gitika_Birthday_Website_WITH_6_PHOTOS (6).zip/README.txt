GITIKA BIRTHDAY WEBSITE

To view on your computer: extract this ZIP, keep the photos and audio folders beside index.html, then double-click index.html.

To publish: upload the ENTIRE extracted folder to Netlify Drop. Do not upload only index.html.

The six photos are already included in the photos folder, and the voice recording is in the audio folder.
